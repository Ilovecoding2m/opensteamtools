@echo off
setlocal
rem ============================================================
rem  CwTools deploy script
rem  Copies CwTools into the local Steam installation and starts Steam.
rem  Put this whole folder wherever you like and run deploy.bat.
rem ============================================================

set "PKG=%~dp0"

rem ---- locate Steam via the registry (fall back to the default path) ----
set "STEAM="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul') do set "STEAM=%%B"
if not defined STEAM set "STEAM=C:\Program Files (x86)\Steam"
if not exist "%STEAM%\steam.exe" (
    echo Steam was not found at "%STEAM%".
    echo Edit this file and put your real Steam path after set "STEAM=".
    pause
    exit /b 1
)
echo Steam directory: %STEAM%

rem ---- close Steam so the DLLs are not locked ----
echo Closing Steam...
taskkill /f /im steam.exe        >nul 2>&1
taskkill /f /im steamwebhelper.exe >nul 2>&1
taskkill /f /im steamservice.exe >nul 2>&1
timeout /t 3 /nobreak >nul

rem ---- copy files into the Steam directory ----
copy /y "%PKG%CwTools.dll"   "%STEAM%\CwTools.dll"    >nul
copy /y "%PKG%dwmapi.dll"    "%STEAM%\dwmapi.dll"     >nul
copy /y "%PKG%xinput1_4.dll" "%STEAM%\xinput1_4.dll"  >nul
copy /y "%PKG%cwtools.toml"  "%STEAM%\cwtools.toml"   >nul
xcopy /y /e /i /q "%PKG%cwtools" "%STEAM%\cwtools"    >nul
xcopy /y /e /i /q "%PKG%config"  "%STEAM%\config"     >nul

echo Done. Launching Steam...
start "" "%STEAM%\steam.exe"
endlocal
